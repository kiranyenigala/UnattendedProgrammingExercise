package com.sky.library;

public final class BookPrefix {

    public static final String BOOK_PREFIX = "BOOK-";

    private BookPrefix() {
    }
}
